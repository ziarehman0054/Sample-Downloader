# Simple Downloader Android — starter project

This is a native Android Studio starter project.

## What currently works
- Reads a copied HTTP/HTTPS link when the app is opened in the foreground.
- Accepts links shared to it from another app using Android's Share menu.
- Downloads direct media/file URLs using Android DownloadManager.
- Shows the system download notification and saves to the Downloads folder.

## Important limitations
- Android does not allow an app to silently monitor the clipboard continuously in the background. This app checks the clipboard while it is in the foreground.
- A YouTube/Instagram/TikTok/Facebook page URL is usually not a direct media-file URL. This starter does not extract streams from those pages or bypass DRM, login restrictions, private content, or platform rules.
- Provider-specific support must use official/authorized download APIs or links that the provider permits users to download.

## Build APK
1. Install Android Studio (current stable) on Windows.
2. Open this folder as an existing project.
3. Allow Gradle sync and install any requested Android SDK platform (API 35).
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the APK location when the build finishes.

Package ID: `com.example.simpledownloader`
