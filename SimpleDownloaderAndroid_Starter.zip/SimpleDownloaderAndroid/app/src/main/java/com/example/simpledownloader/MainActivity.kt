package com.example.simpledownloader

import android.app.Activity
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.net.URLUtil

class MainActivity : Activity() {
    private lateinit var linkInput: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        handleSharedLink(intent)
        readClipboardIfUrl()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleSharedLink(intent)
    }

    override fun onResume() {
        super.onResume()
        // Android only permits clipboard access while this app is foregrounded.
        if (::linkInput.isInitialized && linkInput.text.isNullOrBlank()) readClipboardIfUrl()
    }

    private fun buildScreen() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 24)
            setBackgroundColor(0xFFF6F7FB.toInt())
        }

        val title = TextView(this).apply {
            text = "Simple Downloader"
            textSize = 26f
            setTextColor(0xFF20243A.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Copy a permitted video link, then open this app"
            textSize = 14f
            setTextColor(0xFF62677A.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 24)
        }
        linkInput = EditText(this).apply {
            hint = "Paste video or direct media link"
            textSize = 15f
            minLines = 2
            maxLines = 4
            setPadding(16, 14, 16, 14)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        val paste = Button(this).apply {
            text = "Paste link"
            setOnClickListener { readClipboardIfUrl(showMessage = true) }
        }
        val download = Button(this).apply {
            text = "Download"
            setOnClickListener { startDownload() }
        }
        status = TextView(this).apply {
            text = "Ready"
            textSize = 13f
            setTextColor(0xFF555B70.toInt())
            setPadding(0, 18, 0, 0)
        }
        val note = TextView(this).apply {
            text = "Note: This starter version downloads direct media URLs and links shared by other apps. Website page links may need an official download option or a supported provider integration. It does not bypass DRM, private access, or platform restrictions."
            textSize = 12f
            setTextColor(0xFF707589.toInt())
            setPadding(0, 22, 0, 0)
        }

        listOf(title, subtitle, linkInput, paste, download, status, note).forEach { view ->
            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            params.bottomMargin = 12
            outer.addView(view, params)
        }
        setContentView(outer)
    }

    private fun handleSharedLink(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND && intent.type == "text/plain") {
            val shared = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim().orEmpty()
            if (shared.isNotEmpty()) linkInput.setText(shared)
        }
    }

    private fun readClipboardIfUrl(showMessage: Boolean = false) {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        if (!clipboard.hasPrimaryClip()) {
            if (showMessage) toast("Clipboard is empty")
            return
        }
        val clip: ClipData? = clipboard.primaryClip
        val candidate = clip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim().orEmpty()
        if (candidate.startsWith("https://") || candidate.startsWith("http://")) {
            linkInput.setText(candidate)
            status.text = "Link detected from clipboard"
        } else if (showMessage) {
            toast("No web link found in clipboard")
        }
    }

    private fun startDownload() {
        val raw = linkInput.text.toString().trim()
        if (raw.isEmpty()) {
            toast("Please paste a link first")
            return
        }
        val uri = try { Uri.parse(raw) } catch (_: Exception) { null }
        if (uri == null || (uri.scheme != "https" && uri.scheme != "http") || uri.host.isNullOrBlank()) {
            toast("Please enter a valid http/https link")
            return
        }

        // DownloadManager can fetch direct file URLs; a normal social-media page URL
        // is not necessarily a media file and cannot be converted here.
        val request = DownloadManager.Request(uri)
            .setTitle(URLUtil.guessFileName(raw, null, null))
            .setDescription("Downloading permitted media")
            .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            .setDestinationInExternalPublicDir(
                Environment.DIRECTORY_DOWNLOADS,
                URLUtil.guessFileName(raw, null, null)
            )
            .setAllowedOverMetered(true)
            .setAllowedOverRoaming(false)

        try {
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            status.text = "Download added. Check your Downloads folder."
            toast("Download started")
        } catch (e: Exception) {
            status.text = "Could not start download: ${e.localizedMessage ?: "unknown error"}"
            toast("Download could not start")
        }
    }

    private fun toast(message: String) =
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
